package AOL_Kel5;

public class Specification {
    private int ram;
    private int storage;

    public Specification(int ram, int storage) {
        this.ram = ram;
        this.storage = storage;
    }

    public int getRam() {
        return ram;
    }

    public int getStorage() {
        return storage;
    }
}

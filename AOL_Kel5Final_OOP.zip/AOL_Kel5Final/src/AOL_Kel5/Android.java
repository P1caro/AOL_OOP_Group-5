package AOL_Kel5;

public class Android extends Phone {
    private String androidVersion;

    public Android(int id, String name, double price, int stock, Brand brand, Specification spec, String androidVersion) {
        super(id, name, price, stock, brand, spec);
        this.androidVersion = androidVersion;
    }

    public String getType() {
        return "Android " + androidVersion;
    }
}



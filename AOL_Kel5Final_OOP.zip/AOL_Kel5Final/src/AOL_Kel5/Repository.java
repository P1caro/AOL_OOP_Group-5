package AOL_Kel5;

import java.util.List;

public interface Repository<T> {
    void add(T data);
    void remove(int id);
    List<T> getAll();
}




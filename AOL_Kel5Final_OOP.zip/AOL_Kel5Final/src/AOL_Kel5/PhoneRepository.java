package AOL_Kel5;

import java.util.List;
import java.util.ArrayList;

public class PhoneRepository implements Repository<Phone> {
    private List<Phone> data = new ArrayList<Phone>();

    public void add(Phone hp) {
        data.add(hp);
    }

    public void remove(int id) {
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getId() == id) {
                data.remove(i);
                return;
            }
        }
    }

    public List<Phone> getAll() {
        return data;
    }
}



package AOL_Kel5;

import java.util.Scanner;

public class PhoneService {
    private Scanner sc = new Scanner(System.in);
    private Repository<Phone> repo = new PhoneRepository();
    private int idCounter = 1;

    public static <T> void printAny(T data) {
        System.out.println(data);
    }
    
    public void addPhone() {
        System.out.println("\n=== Add Phone ===");

        System.out.print("Brand                       : ");
        Brand brand = new Brand(sc.nextLine());

        System.out.print("Phone Name                  : ");
        String name = sc.nextLine();

        System.out.print("RAM (GB) [number only]      : ");
        int ram = sc.nextInt();

        System.out.print("Storage (GB) [number only]  : ");
        int storage = sc.nextInt();
        sc.nextLine();

        System.out.print("Type (1.Android / 2.iOS)    : ");
        int type = sc.nextInt();
        sc.nextLine();

        Specification spec = new Specification(ram, storage);
        Phone hp;

        if (type == 1) {
            System.out.print("Android Version             : ");
            String v = sc.nextLine();

            System.out.print("Price                       : ");
            double price = sc.nextDouble();

            System.out.print("Stock                       : ");
            int stock = sc.nextInt();
            sc.nextLine();

            hp = new Android(idCounter++, name, price, stock, brand, spec, v);
        } else {
            System.out.print("iOS Version              : ");
            String v = sc.nextLine();

            System.out.print("Price                    : ");
            double price = sc.nextDouble();

            System.out.print("Stock                    : ");
            int stock = sc.nextInt();
            sc.nextLine();

            hp = new IOS(idCounter++, name, price, stock, brand, spec, v);
        }

        repo.add(hp);
        printAny("Phone added successfully!");
    }

    public void viewAll() {
        if (repo.getAll().isEmpty()) {
            printAny("No data.");
            return;
        }

        printTableHeader();
        for (Phone hp : repo.getAll()) {
            printTableRow(hp);
        }
        printTableFooter();
    }

    public void searchPhone() {
        System.out.print("Search keyword : ");
        String key = sc.nextLine().toLowerCase();

        boolean found = false;
        for (Phone hp : repo.getAll()) {
            if (
                hp.getName().toLowerCase().contains(key) ||
                hp.getBrand().getName().toLowerCase().contains(key) ||
                hp.getType().toLowerCase().contains(key) ||
                String.valueOf(hp.getPrice()).contains(key) ||
                String.valueOf(hp.getStock()).contains(key) ||
                String.valueOf(hp.getSpec().getRam()).contains(key) ||
                String.valueOf(hp.getSpec().getStorage()).contains(key)
            ) {
                if (!found) {
                    printTableHeader();
                }
                printTableRow(hp);
                found = true;
            }
        }

        if (found) {
            printTableFooter();
        } else {
            printAny("No matching data found.");
        }
    }

    public void sortByPrice() {
        System.out.println("1. Lowest Price");
        System.out.println("2. Highest Price");
        System.out.print("Choose: ");
        int choice = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < repo.getAll().size(); i++) {
            for (int j = 0; j < repo.getAll().size() - 1; j++) {
                Phone a = repo.getAll().get(j);
                Phone b = repo.getAll().get(j + 1);

                if ((choice == 1 && a.getPrice() > b.getPrice()) ||
                    (choice == 2 && a.getPrice() < b.getPrice())) {
                    repo.getAll().set(j, b);
                    repo.getAll().set(j + 1, a);
                }
            }
        }

        printAny("Sorted successfully!");
        viewAll();
    }

    public void updatePriceAndStock() {
        System.out.print("Phone ID : ");
        int id = sc.nextInt();

        for (Phone hp : repo.getAll()) {
            if (hp.getId() == id) {
                System.out.print("New Price : ");
                double price = sc.nextDouble();

                System.out.print("New Stock : ");
                int stock = sc.nextInt();
                sc.nextLine();

                hp.setPrice(price);
                hp.setStock(stock);

                printAny("Updated successfully!");
                return;
            }
        }
        printAny("ID not found.");
    }

    public void deletePhone() {
        System.out.print("ID: ");
        int id = sc.nextInt();
        repo.remove(id);
        printAny("Deleted!");
    }

    private void printTableHeader() {
        System.out.println("-----------------------------------------------------------------------------------------------------");
        System.out.printf("| %-3s | %-10s | %-20s | %-6s | %-7s | %-10s | %-14s | %-6s |%n",
                "ID", "Brand", "Name", "RAM", "Storage", "Type", "Price", "Stock");
        System.out.println("-----------------------------------------------------------------------------------------------------");
    }

    private void printTableRow(Phone hp) {
        System.out.printf("| %-3d | %-10s | %-20s | %-6s | %-7s | %-10s | Rp%-12.2f | %-6d |%n",
                hp.getId(),
                hp.getBrand().getName(),
                hp.getName(),
                hp.getSpec().getRam() + " GB",
                hp.getSpec().getStorage() + " GB",
                hp.getType(),
                hp.getPrice(),
                hp.getStock()
        );
    }

    private void printTableFooter() {
        System.out.println("-----------------------------------------------------------------------------------------------------");
    }
}





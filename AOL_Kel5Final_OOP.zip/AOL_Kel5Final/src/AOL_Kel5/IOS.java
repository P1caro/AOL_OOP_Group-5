package AOL_Kel5;

public class IOS extends Phone {
    private String iosVersion;

    public IOS(int id, String name, double price, int stock, Brand brand, Specification spec, String iosVersion) {
        super(id, name, price, stock, brand, spec);
        this.iosVersion = iosVersion;
    }

    public String getType() {
        return "iOS " + iosVersion;
    }
}


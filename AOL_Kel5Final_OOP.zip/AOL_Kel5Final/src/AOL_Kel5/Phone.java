package AOL_Kel5;

public abstract class Phone {
	protected Specification spec;
	protected Brand brand;
    protected int id;
    protected String name;
    protected double price;
    protected int stock;

    public Phone(int id, String name, double price, int stock, Brand brand, Specification spec) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.brand = brand;
        this.spec = spec;
    }

    public int getId() {
    	return id;
    }
    
    public String getName() {
    	return name;
    }
    
    public double getPrice() {
    	return price;
    }
    
    public int getStock() {
    	return stock;
    }
    
    public Brand getBrand() {
    	return brand;
    }
    
    public Specification getSpec() {
    	return spec;
    }

    public void setPrice(double price) {
    	this.price = price;
    }
    
    public void setStock(int stock) {
    	this.stock = stock;
    }

    public abstract String getType();
}



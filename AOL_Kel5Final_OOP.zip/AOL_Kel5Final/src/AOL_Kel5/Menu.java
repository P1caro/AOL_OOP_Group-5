package AOL_Kel5;

import java.util.Scanner;

public class Menu {
	private PhoneService service = new PhoneService();
    private Scanner sc = new Scanner(System.in);

    public void start() {
        int choice;
        do {
            System.out.println("\n=== Phone Store Management ===");
            System.out.println("1. Add Phone");
            System.out.println("2. View All Phones");
            System.out.println("3. Update Price & Stock");
            System.out.println("4. Delete Phone");
            System.out.println("5. Search Phone");
            System.out.println("6. Sort by Price");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    service.addPhone();
                    break;
                case 2:
                    service.viewAll();
                    break;
                case 3:
                    service.updatePriceAndStock();
                    break;
                case 4:
                    service.deletePhone();
                    break;
                case 5:
                    service.searchPhone();
                    break;
                case 6:
                    service.sortByPrice();
                    break;
                case 0:
                    System.out.println("Exit program.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }
}



